# scripts/visualization/generate_charts.py
import matplotlib.pyplot as plt
import os
import pandas as pd
from scripts.analysis.analysis import analysis


PLOTS_DIR = "data/plots/"
os.makedirs(PLOTS_DIR, exist_ok=True)


def save_fig(fig, filename):
    if fig is not None:
        fig.savefig(os.path.join(PLOTS_DIR, filename), bbox_inches="tight")
        print(f"[OK] Saved plot: {filename}")
    else:
        print(f"[WARN] No figure generated for: {filename}")

# -----------------------------------------------------
# 1. Rolling Call Volume (from analysis)
# -----------------------------------------------------
def chart_rolling_call_volume():
    analysis_data = analysis()
    df = analysis_data["rolling_call_volume"]

    fig, ax = plt.subplots(figsize=(10, 5))
    ax.plot(df["hour"], df["rolling_calls"], label="Rolling Calls (3 hr)", linewidth=2)
    ax.plot(df["hour"], df["total_calls"], label="Raw Calls", alpha=0.5)
    ax.set_title("Rolling Average – Call Volume")
    ax.set_xlabel("Hour of Day")
    ax.set_ylabel("Call Count")
    ax.legend()
    save_fig(fig, "rolling_call_volume.png")

# -----------------------------------------------------
# 2. State Heatmap Scatter (lat/long)
# -----------------------------------------------------
def chart_state_heatmap():
    analysis_data = analysis()
    df = analysis_data["state_heatmap"]

    if df.empty:
        return None

    # Use correct column name
    if "drop_rate_pct" in df.columns:
        drop_col = "drop_rate_pct"
    else:
        # fallback in case column name changes in future
        drop_col = [c for c in df.columns if "drop" in c.lower()][0]

    fig, ax = plt.subplots(figsize=(8, 6))
    scatter = ax.scatter(
        df["longitude"],
        df["latitude"],
        c=df[drop_col],
        cmap="Reds",
        s=200
    )

    ax.set_title("Drop Rate Heatmap (State Centroids)")
    ax.set_xlabel("Longitude")
    ax.set_ylabel("Latitude")
    plt.colorbar(scatter, label="Drop Rate (%)")
    save_fig(fig, "state_heatmap.png")

# -----------------------------------------------------
# 3. Customer Segments Chart
# -----------------------------------------------------
def chart_customer_segments():
    analysis_data = analysis()
    df = analysis_data["customer_segments"]

    seg_counts = df["usage_segment"].value_counts()

    fig, ax = plt.subplots(figsize=(6, 4))
    ax.bar(seg_counts.index, seg_counts.values, color=["green", "orange", "red"])
    ax.set_title("Customer Usage Segments")
    ax.set_ylabel("Number of Users")
    save_fig(fig, "customer_segments.png")

