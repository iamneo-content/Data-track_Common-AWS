import pandas as pd
import os
from datetime import datetime

EXPORT_PATH = "data/exports/"
LOG_FILE = "logs/alerts.log"


def log_alert(message):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with open(LOG_FILE, "a") as f:
        f.write(f"[{timestamp}] {message}\n")
    print("[ALERT]", message)


def check_drop_rate():
    df = pd.read_csv(os.path.join(EXPORT_PATH, "drop_rate_by_state.csv"))

    # Convert to float safely
    df["drop_rate_pct"] = pd.to_numeric(df["drop_rate_pct"], errors="coerce")

    risky = df[df["drop_rate_pct"] > 50]

    for _, r in risky.iterrows():
        msg = f"HIGH DROP RATE: {r['state_name']} at {r['drop_rate_pct']:.2f}%"
        log_alert(msg)


def check_low_signal():
    df = pd.read_csv(os.path.join(EXPORT_PATH, "operator_quality.csv"))
    weak = df[df["avg_signal"] < -90]

    for _, r in weak.iterrows():
        msg = f"LOW SIGNAL: {r['operator_name']} at {r['avg_signal']} dBm"
        log_alert(msg)


def check_inactive_towers():
    df = pd.read_csv(os.path.join(EXPORT_PATH, "tower_performance.csv"))
    inactive = df[df["total_calls"] == 0]

    for _, r in inactive.iterrows():
        msg = f"INACTIVE TOWER: ID {r['tower_id']} has 0 calls"
        log_alert(msg)


def run_alerts():
    print("\n=== Running Automated Network Alerts ===")
    check_drop_rate()
    check_low_signal()
    check_inactive_towers()
    print("=== Alerts Checked ===")


if __name__ == "__main__":
    run_alerts()
