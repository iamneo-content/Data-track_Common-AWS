import smtplib
import yaml
from email.mime.text import MIMEText
import pandas as pd
import os

EXPORT_PATH = "data/exports/"
CONFIG_PATH = "config/email_config.yaml"


def load_csv(name):
    return pd.read_csv(os.path.join(EXPORT_PATH, name))


def load_email_config():
    with open(CONFIG_PATH, "r") as f:
        return yaml.safe_load(f)


def build_email_body():
    drop = load_csv("drop_rate_by_state.csv")
    opq = load_csv("operator_quality.csv")
    peak = load_csv("peak_hours.csv")

    highest_drop = drop.sort_values("drop_rate_pct", ascending=False).iloc[0]
    worst_operator = opq.sort_values("avg_signal").iloc[0]
    peak_hour = peak.sort_values("total_calls", ascending=False).iloc[0]["hour"]

    body = f"""
    DAILY TELECOM NETWORK SUMMARY

     Highest Drop-Rate State:
        {highest_drop['state_name']} ({highest_drop['drop_rate_pct']:.2f}%)

     Worst Operator Signal:
        {worst_operator['operator_name']} ({worst_operator['avg_signal']} dBm)

     Peak Hour:
        {peak_hour} hrs

    Regards,
    Telecom Monitoring System
    """

    return body


def send_email_summary():
    config = load_email_config()

    msg = MIMEText(build_email_body())
    msg["Subject"] = "Daily Network Performance Summary"
    msg["From"] = config["from_email"]
    msg["To"] = config["to_email"]

    with smtplib.SMTP(config["smtp_host"], config["smtp_port"]) as server:
        server.starttls()
        server.login(config["from_email"], config["app_password"])
        server.send_message(msg)

    print(f"[EMAIL] Summary sent to {config['to_email']}")


if __name__ == "__main__":
    send_email_summary()

