import pandas as pd
import numpy as np
import os

EXPORT_PATH = "data/exports/"
PROCESSED_PATH = "data/processed/"

def load_csv(name):
    return pd.read_csv(os.path.join(EXPORT_PATH, name))

def analysis():
    analysis = {}

    # 1. Rolling average for call volume
    peak = load_csv("peak_hours.csv")
    peak = peak.sort_values("hour")
    peak["rolling_calls"] = peak["total_calls"].rolling(window=3, min_periods=1).mean()
    analysis["rolling_call_volume"] = peak

    # 2. State heatmap data
    drop_rate = load_csv("drop_rate_by_state.csv")
    towers = pd.read_csv(os.path.join(PROCESSED_PATH, "towers_clean.csv"))

    # Each state has one tower coordinate? No → use state centroid (average)
    coords = towers.groupby("state_name")[["latitude", "longitude"]].mean().reset_index()
    heatmap = drop_rate.merge(coords, on="state_name", how="left")
    analysis["state_heatmap"] = heatmap

    # 3. Customer segmentation (light / medium / heavy)
    heavy_users = load_csv("heavy_users.csv")  # already has total_duration
    segments = []

    for _, row in heavy_users.iterrows():
        dur = row["total_duration"]
        if dur < 2000:
            seg = "Light"
        elif dur < 8000:
            seg = "Medium"
        else:
            seg = "Heavy"
        segments.append(seg)

    heavy_users["usage_segment"] = segments
    analysis["customer_segments"] = heavy_users

    # 4. Data usage distribution
    opq = load_csv("operator_quality.csv")
    # Distribution can be simple describing signal or drop_rate
    opq_stats = opq.describe()
    analysis["usage_distribution"] = opq_stats

    return analysis


if __name__ == "__main__":
    result = analysis()
    for key, df in result.items():
        print("\n=== ", key, " ===")
        print(df.head())
