import pandas as pd
import numpy as np
import os

RAW_PATH = "data/raw/customers.csv"
OUT_PATH = "data/processed/customers_clean.csv"

def clean_customers():
    print("[CUSTOMERS] Loading raw customers.csv ...")
    df = pd.read_csv(RAW_PATH)

    # ---------------------------------------------------------
    # 1. CLEAN PHONE NUMBERS
    # ---------------------------------------------------------
    def clean_phone(num):
        if pd.isna(num):
            return np.nan
        num = str(num).strip().replace(" ", "").replace("-", "")
        if not num.isdigit():
            return np.nan
        if len(num) != 10:
            return np.nan
        return num

    df["phone_number"] = df["phone_number"].apply(clean_phone)
    df = df.dropna(subset=["phone_number"])

    # ---------------------------------------------------------
    # 2. NORMALIZE PLAN TYPE
    # ---------------------------------------------------------
    df["plan_type"] = df["plan_type"].astype(str).str.lower().str.strip()

    mapping = {
        "prepaid": "Prepaid",
        "pre paid": "Prepaid",
        "prepaid ": "Prepaid",
        "pre-paid": "Prepaid",
        "postpaid": "Postpaid",
        "post-paid": "Postpaid",
        "postpaid ": "Postpaid",
        "postpaid  ": "Postpaid"
    }

    df["plan_type"] = df["plan_type"].replace(mapping)
    df["plan_type"] = df["plan_type"].fillna("Prepaid")

    # ---------------------------------------------------------
    # 3. CLEAN BILLING AMOUNT
    # ---------------------------------------------------------
    df["billing_amount"] = (
        df["billing_amount"]
        .astype(str)
        .str.replace("₹", "")
        .str.replace(",", "")
        .str.strip()
    )

    df["billing_amount"] = pd.to_numeric(df["billing_amount"], errors="coerce")
    df["billing_amount"] = df["billing_amount"].clip(lower=0, upper=20000)
    df["billing_amount"].fillna(df["billing_amount"].median(), inplace=True)

    # ---------------------------------------------------------
    # 4. CLEAN CUSTOMER SEGMENT
    # ---------------------------------------------------------
    df["customer_segment"] = df["customer_segment"].astype(str).str.strip().str.lower()

    seg_map = {
        "low": "Low",
        "": "Low",
        "nan": "Low",
        "med": "Medium",
        "medium": "Medium",
        "high": "High"
    }

    df["customer_segment"] = df["customer_segment"].replace(seg_map)
    df["customer_segment"] = df["customer_segment"].fillna("Low")

    # ---------------------------------------------------------
    # 5. NORMALIZE ROAMING FLAG
    # ---------------------------------------------------------
    df["roaming_flag"] = df["roaming_flag"].astype(str).str.lower().str.strip()

    df["roaming_flag"] = df["roaming_flag"].replace({
        "yes": 1, "y": 1, "true": 1, "1": 1,
        "no": 0, "n": 0, "false": 0, "0": 0
    }).astype(int)

    # ---------------------------------------------------------
    # 6. SAVE CLEAN OUTPUT
    # ---------------------------------------------------------
    os.makedirs("data/processed", exist_ok=True)
    df.to_csv(OUT_PATH, index=False)

    print(f"[CUSTOMERS] Cleaned file saved: {OUT_PATH} ({df.shape[0]} rows)\n")
