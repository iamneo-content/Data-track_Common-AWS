import os
import pandas as pd
import numpy as np

RAW_DIR = "data/raw/cdr_calls/"
OUT_DIR = "data/processed/cdr_calls/"


def clean_cdr_calls():
    print("[CDR] Starting CDR cleaning process...")

    # Ensure output directory exists
    os.makedirs(OUT_DIR, exist_ok=True)

    # Get all CDR part files
    part_files = [f for f in os.listdir(RAW_DIR) if f.endswith(".csv")]
    part_files.sort()  # ensure part_1, part_2, etc.

    if len(part_files) == 0:
        print("[CDR][ERROR] No part files found in data/raw/cdr_calls/")
        return

    for file in part_files:
        input_path = os.path.join(RAW_DIR, file)
        print(f"[CDR] Loading {file} ...")

        df = pd.read_csv(input_path)

        # ------------------------------------
        # 1. CLEAN PHONE NUMBERS
        # ------------------------------------
        def clean_phone(num):
            if pd.isna(num):
                return np.nan
            num = str(num).replace(" ", "").replace("-", "")
            if not num.isdigit():
                return np.nan
            if len(num) != 10:
                return np.nan
            return num

        df["caller_number"] = df["caller_number"].apply(clean_phone)
        df["receiver_number"] = df["receiver_number"].apply(clean_phone)
        df = df.dropna(subset=["caller_number"])

        # ------------------------------------
        # 2. FIX TIMESTAMP FORMATS
        # ------------------------------------
        def parse_ts(x):
            try:
                return pd.to_datetime(x, errors="coerce", infer_datetime_format=True)
            except:
                return pd.NaT

        df["call_start_timestamp"] = df["call_start_timestamp"].apply(parse_ts)
        df["call_end_timestamp"] = df["call_end_timestamp"].apply(parse_ts)

        # end < start → fix
        mask = df["call_end_timestamp"] < df["call_start_timestamp"]
        df.loc[mask, "call_end_timestamp"] = df.loc[mask, "call_start_timestamp"]

        # ------------------------------------
        # 3. FIX DURATION
        # ------------------------------------
        df["call_duration_seconds"] = (
            (df["call_end_timestamp"] - df["call_start_timestamp"]).dt.total_seconds()
        )
        df["call_duration_seconds"] = df["call_duration_seconds"].clip(lower=0)
        df["call_duration_seconds"].fillna(0, inplace=True)

        # ------------------------------------
        # 4. NORMALIZE CALL TYPE
        # ------------------------------------
        df["call_type"] = df["call_type"].astype(str).str.strip().str.lower()
        mapping = {
            "local": "Local",
            "std": "STD",
            "inter national": "International",
            "international": "International",
            "int.": "International",
        }
        df["call_type"] = df["call_type"].replace(mapping)

        # ------------------------------------
        # 5. NORMALIZE NETWORK TYPE
        # ------------------------------------
        df["network_type"] = (
            df["network_type"]
            .astype(str)
            .str.replace(" ", "")
            .str.replace("g", "G")
        )
        df["network_type"] = df["network_type"].replace({"FIVEG": "5G"})

        # ------------------------------------
        # 6. SIGNAL STRENGTH CLEANING
        # ------------------------------------
        df["signal_strength_dbm"] = pd.to_numeric(df["signal_strength_dbm"], errors="coerce")
        df["signal_strength_dbm"] = df["signal_strength_dbm"].clip(-110, -60)
        df["signal_strength_dbm"].fillna(df["signal_strength_dbm"].median(), inplace=True)

        # ------------------------------------
        # 7. CALL DROP FLAG NORMALIZATION
        # ------------------------------------
        df["call_drop_flag"] = df["call_drop_flag"].astype(str).str.lower().str.strip()
        df["call_drop_flag"] = df["call_drop_flag"].replace({
            "yes": 1, "y": 1, "1": 1, "dropped": 1,
            "no": 0, "n": 0, "0": 0, "ok": 0
        }).astype(int)

        # ------------------------------------
        # 8. DATA USAGE CLEANING
        # ------------------------------------
        df["data_usage_mb"] = (
            df["data_usage_mb"]
            .astype(str)
            .str.replace("MB", "")
            .str.replace("mb", "")
            .str.strip()
        )
        df["data_usage_mb"] = pd.to_numeric(df["data_usage_mb"], errors="coerce")
        df["data_usage_mb"] = df["data_usage_mb"].clip(lower=0, upper=5000)
        df["data_usage_mb"].fillna(0, inplace=True)

        # ------------------------------------
        # SAVE OUTPUT (same part number)
        # ------------------------------------
        cleaned_filename = file.replace("cdr_calls_part_", "cdr_calls_clean_part_")
        output_path = os.path.join(OUT_DIR, cleaned_filename)

        df.to_csv(output_path, index=False)
        print(f"[CDR] Saved cleaned → {cleaned_filename} ({df.shape[0]} rows)\n")

    print("[CDR] All CDR part files cleaned successfully!\n")
