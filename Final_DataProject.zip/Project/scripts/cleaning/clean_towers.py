import pandas as pd
import os

RAW_PATH = "data/raw/towers.csv"
OUT_PATH = "data/processed/towers_clean.csv"

def clean_towers():
    print("[TOWERS] Loading raw towers.csv ...")
    df = pd.read_csv(RAW_PATH)

    # ---------------------------------------------------------
    # 1. DROP DUPLICATES
    # ---------------------------------------------------------
    df = df.drop_duplicates(subset=["tower_id"], keep="first")

    # ---------------------------------------------------------
    # 2. FIX STATE NAMES (e.g., Himachal Pradesh)
    # ---------------------------------------------------------
    df["state_name"] = (
        df["state_name"]
        .astype(str)
        .str.strip()
        .str.title()
    )

    # ---------------------------------------------------------
    # 3. CONVERT LAT/LONG TO NUMERIC
    # ---------------------------------------------------------
    df["latitude"] = pd.to_numeric(df["latitude"], errors="coerce")
    df["longitude"] = pd.to_numeric(df["longitude"], errors="coerce")

    df = df.dropna(subset=["latitude", "longitude"])

    # ---------------------------------------------------------
    # 4. FIX OPERATOR NAME
    # ---------------------------------------------------------
    df["operator_name"] = (
        df["operator_name"].astype(str).str.strip().str.title()
    )

    # ---------------------------------------------------------
    # 5. SAVE CLEANED OUTPUT
    # ---------------------------------------------------------
    os.makedirs("data/processed", exist_ok=True)
    df.to_csv(OUT_PATH, index=False)

    print(f"[TOWERS] Cleaned file saved: {OUT_PATH} ({df.shape[0]} rows)\n")
