-- ===========================================
-- CREATE DIMENSION TABLES
-- ===========================================

DROP TABLE IF EXISTS dim_customer;
DROP TABLE IF EXISTS dim_tower;
DROP TABLE IF EXISTS fact_calls;

CREATE TABLE dim_customer (
    customer_id INTEGER PRIMARY KEY,
    phone_number TEXT NOT NULL,
    plan_type TEXT,
    billing_amount REAL,
    customer_segment TEXT,
    roaming_flag INTEGER
);

CREATE TABLE dim_tower (
    tower_id INTEGER PRIMARY KEY,
    state_name TEXT,
    latitude REAL,
    longitude REAL,
    operator_name TEXT
);

-- ===========================================
-- CREATE FACT TABLE
-- ===========================================

CREATE TABLE fact_calls (
    call_id INTEGER PRIMARY KEY,
    caller_number TEXT,
    receiver_number TEXT,
    call_start_timestamp TEXT,
    call_end_timestamp TEXT,
    call_duration_seconds INTEGER,
    call_type TEXT,
    tower_id INTEGER,
    network_type TEXT,
    signal_strength_dbm INTEGER,
    call_drop_flag INTEGER,
    data_usage_mb REAL,
    state_name TEXT,
    latitude REAL,
    longitude REAL,

    FOREIGN KEY (tower_id) REFERENCES dim_tower(tower_id)
);
