import sqlite3
import pandas as pd
import glob
import os

DB_PATH = "data/telecom.db"
PROCESSED_PATH = "data/processed/"

def load_dim_customer(conn):
    df = pd.read_csv(os.path.join(PROCESSED_PATH, "customers_clean.csv"))
    df.to_sql("dim_customer", conn, if_exists="append", index=False)
    print("[SQL] Loaded dim_customer")


def load_dim_tower(conn):
    df = pd.read_csv(os.path.join(PROCESSED_PATH, "towers_clean.csv"))
    df.to_sql("dim_tower", conn, if_exists="append", index=False)
    print("[SQL] Loaded dim_tower")


def load_fact_calls(conn):
    cdr_path = os.path.join(PROCESSED_PATH, "cdr_calls", "*.csv")
    files = glob.glob(cdr_path)

    for f in files:
        print(f"[SQL] Loading {f} ...")
        df = pd.read_csv(f)
        df.to_sql("fact_calls", conn, if_exists="append", index=False)

    print("[SQL] Loaded fact_calls (all split files)")


def sql_load_main():
    print("\n[SQL] Connecting to SQLite DB...")
    conn = sqlite3.connect(DB_PATH)

    print("[SQL] Loading dimensions...")
    load_dim_customer(conn)
    load_dim_tower(conn)

    print("[SQL] Loading fact_calls...")
    load_fact_calls(conn)

    conn.close()
    print("[SQL] DONE loading all tables.\n")


if __name__ == "__main__":
    sql_load_main()
