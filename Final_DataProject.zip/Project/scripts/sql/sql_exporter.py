import sqlite3
import pandas as pd
import os

DB_PATH = "data/telecom.db"
EXPORT_DIR = "data/exports/"

VIEWS = {
    "drop_rate_by_state": "view_drop_rate_by_state",
    "operator_quality": "view_operator_quality",
    "peak_hours": "view_peak_hours",
    "tower_performance": "view_tower_performance",
    "heavy_users": "view_heavy_users",
    "signal_correlation": "view_signal_correlation"
}

def export_views():
    conn = sqlite3.connect(DB_PATH)

    if not os.path.exists(EXPORT_DIR):
        os.makedirs(EXPORT_DIR)

    for filename, view_name in VIEWS.items():
        df = pd.read_sql_query(f"SELECT * FROM {view_name}", conn)
        output_path = os.path.join(EXPORT_DIR, f"{filename}.csv")
        df.to_csv(output_path, index=False)
        print(f"[EXPORT] {view_name} → {output_path}")

    conn.close()
    print("[EXPORT] All SQL views exported successfully.")


if __name__ == "__main__":
    export_views()
