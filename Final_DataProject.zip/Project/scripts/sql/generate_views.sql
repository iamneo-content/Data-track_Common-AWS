DROP VIEW IF EXISTS view_drop_rate_by_state;
CREATE VIEW view_drop_rate_by_state AS
SELECT
    state_name,
    AVG(call_drop_flag) * 100 AS drop_rate_pct
FROM fact_calls
GROUP BY state_name;

DROP VIEW IF EXISTS view_peak_hours;
CREATE VIEW view_peak_hours AS
SELECT
    strftime('%H', call_start_timestamp) AS hour,
    COUNT(*) AS total_calls
FROM fact_calls
GROUP BY hour;

DROP VIEW IF EXISTS view_operator_quality;
CREATE VIEW view_operator_quality AS
SELECT
    t.operator_name,
    AVG(f.signal_strength_dbm) AS avg_signal,
    AVG(f.call_drop_flag) * 100 AS drop_rate
FROM fact_calls f
JOIN dim_tower t ON f.tower_id = t.tower_id
GROUP BY t.operator_name;

DROP VIEW IF EXISTS view_signal_correlation;
CREATE VIEW view_signal_correlation AS
SELECT
    CASE
        WHEN signal_strength_dbm >= -70 THEN 'Excellent'
        WHEN signal_strength_dbm >= -85 THEN 'Good'
        ELSE 'Poor'
    END AS signal_bucket,
    AVG(call_drop_flag) * 100 AS drop_rate
FROM fact_calls
GROUP BY signal_bucket;

DROP VIEW IF EXISTS view_tower_performance;
CREATE VIEW view_tower_performance AS
SELECT
    tower_id,
    COUNT(*) AS total_calls,
    AVG(signal_strength_dbm) AS avg_signal,
    SUM(call_drop_flag) AS dropped_calls
FROM fact_calls
GROUP BY tower_id;

DROP VIEW IF EXISTS view_heavy_users;DROP VIEW IF EXISTS view_heavy_users;
CREATE VIEW view_heavy_users AS
SELECT
    caller_number,
    COUNT(*) AS call_count,
    SUM(call_duration_seconds) AS total_duration
FROM fact_calls
GROUP BY caller_number
ORDER BY call_count DESC
LIMIT 10;




