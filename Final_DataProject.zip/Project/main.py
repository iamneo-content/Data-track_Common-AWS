"""
MAIN TELECOM CDR – ANALYSIS, VISUALIZATION, ALERTS, EMAIL
----------------------------------------------------------
Run this AFTER build.py generates SQL DW and exports. dum
"""

import os
from scripts.visualization import generate_charts
from scripts.automation.alert_drop_rate import run_alerts
from scripts.automation.send_email_summary import send_email_summary


def run_main():

    print("\n===============================")
    print(" TELECOM CDR – FULL ANALYSIS PIPELINE")
    print("===============================")

    # -----------------------------
    # STEP 1 — PYTHON ANALYSIS
    # -----------------------------

    # -----------------------------
    # STEP 2 — VISUALIZATIONS
    # -----------------------------
    print("\nStep 2 — Generating Visualizations...")

    generate_charts.chart_rolling_call_volume()
    generate_charts.chart_state_heatmap()
    generate_charts.chart_customer_segments()

    # -----------------------------
    # STEP 3 — ALERTS
    # -----------------------------
    print("\nStep 3 — Running Automated Alerts...")
    run_alerts()

    # -----------------------------
    # STEP 4 — EMAIL SUMMARY
    # -----------------------------
    print("\nStep 4 — Sending Daily Summary Email...")
    send_email_summary()

    print("\n===============================")
    print(" FULL ANALYSIS + ALERTS + EMAIL COMPLETE")
    print("===============================\n")


if __name__ == "__main__":
    run_main()



