"""
MAIN PIPELINE CONTROLLER (CURRENT PROGRESS)
-------------------------------------------
This version runs ONLY the cleaning stage,
because SQL loading, views, analysis, and
exports will be added in the next steps.
"""

from scripts.cleaning.clean_cdr_calls import clean_cdr_calls
from scripts.cleaning.clean_customers import clean_customers
from scripts.cleaning.clean_towers import clean_towers

def run_cleaning():
    print("\n====================================")
    print(" TELECOM CDR PIPELINE - STARTING ")
    print("====================================\n")

    # STEP 1: CLEAN CDR CALLS (split files)
    print("STEP 1: Cleaning CDR Call Split Files...")
    clean_cdr_calls()

    # STEP 2: CLEAN CUSTOMERS
    print("STEP 2: Cleaning Customers...")
    clean_customers()

    # STEP 3: CLEAN TOWERS
    print("STEP 3: Cleaning Towers...")
    clean_towers()

    print("\n====================================")
    print(" PIPELINE COMPLETED (CURRENT STAGE) ")
    print("====================================\n")


if __name__ == "__main__":
    run_cleaning()
