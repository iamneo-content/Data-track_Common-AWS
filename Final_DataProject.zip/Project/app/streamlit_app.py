import streamlit as st
import os

st.set_page_config(page_title="Telecom CDR – Visualizations", layout="wide")

st.title(" Telecom Network Quality – Visualization Viewer")

PLOTS_DIR = "data/plots/"

if not os.path.exists(PLOTS_DIR):
    st.error("Plots folder not found. Run `python main.py` first.")
    st.stop()

images = [f for f in os.listdir(PLOTS_DIR) if f.endswith(".png")]

if not images:
    st.warning("No plots found. Run `python main.py` to generate charts.")
    st.stop()

for img in sorted(images):
    st.subheader(img.replace(".png", "").replace("_", " ").title())
    st.image(os.path.join(PLOTS_DIR, img), use_column_width=True)
