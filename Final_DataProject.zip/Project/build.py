"""
BUILD TELECOM CDR DATA WAREHOUSE
---------------------------------
This script:
- Creates SQL tables
- Loads cleaned data into SQLite DW
- Creates all SQL views
- Exports analytics CSVs

Run this AFTER running cleaning.py
"""

import sqlite3
from scripts.sql.load_dim_fact import sql_load_main
import scripts.sql.sql_exporter as exporter

def create_tables():
    conn = sqlite3.connect("data/telecom.db")
    cursor = conn.cursor()
    with open("scripts/sql/create_tables.sql", "r") as f:
        cursor.executescript(f.read())
    conn.commit()
    conn.close()
    print("[BUILD] Tables created from create_tables.sql.")

def run_sql_views():
    conn = sqlite3.connect("data/telecom.db")
    cursor = conn.cursor()

    with open("scripts/sql/generate_views.sql", "r") as f:
        cursor.executescript(f.read())

    conn.commit()
    conn.close()

    print("[BUILD] SQL Views created.")

def build_dw():
    print("\n============================")
    print(" BUILDING TELECOM CDR DW ")
    print("============================\n")

    print("Step 1 — Creating Tables...")
    create_tables()

    print("Step 2 — Loading Cleaned Data into SQL DW...")
    sql_load_main()

    print("Step 3 — Creating SQL Views...")
    run_sql_views()

    print("Step 3 — Exporting SQL View Outputs...")
    exporter.export_views()

    print("\n============================")
    print(" BUILD COMPLETE ")
    print("============================\n")

if __name__ == "__main__":
    build_dw()
