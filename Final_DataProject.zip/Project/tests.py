# tests.py
# Run: pytest -q

import os
import glob
import sqlite3
import importlib
import pandas as pd
import re

DB_PATH = "data/telecom.db"
RAW_DIR = "data/raw"
PROCESSED_DIR = "data/processed"
PROCESSED_CDR_DIR = os.path.join(PROCESSED_DIR, "cdr_calls")
EXPORTS_DIR = "data/exports"
PLOTS_DIR = "data/plots"
LOGS_DIR = "logs"
ALERTS_LOG = os.path.join(LOGS_DIR, "alerts.log")

EXPECTED_EXPORTS = [
    "drop_rate_by_state.csv",
    "operator_quality.csv",
    "peak_hours.csv",
    "tower_performance.csv",
    "heavy_users.csv",
]

EXPECTED_PLOTS = [
    "rolling_call_volume.png",
    "state_heatmap.png",
    "customer_segments.png",
]

INDIAN_STATES = [
    "Andhra Pradesh","Arunachal Pradesh","Assam","Bihar","Chhattisgarh","Goa",
    "Gujarat","Haryana","Himachal Pradesh","Jharkhand","Karnataka","Kerala",
    "Madhya Pradesh","Maharashtra","Manipur","Meghalaya","Mizoram","Nagaland",
    "Odisha","Punjab","Rajasthan","Sikkim","Tamil Nadu","Telangana","Tripura",
    "Uttar Pradesh","Uttarakhand","West Bengal","Delhi","Jammu And Kashmir","Ladakh"
]

def _ensure_dirs():
    os.makedirs(PROCESSED_DIR, exist_ok=True)
    os.makedirs(PROCESSED_CDR_DIR, exist_ok=True)
    os.makedirs(EXPORTS_DIR, exist_ok=True)
    os.makedirs(PLOTS_DIR, exist_ok=True)
    os.makedirs(LOGS_DIR, exist_ok=True)

def _ensure_dw_built():
    have_db = os.path.exists(DB_PATH)
    have_exports = all(os.path.exists(os.path.join(EXPORTS_DIR, f)) for f in EXPECTED_EXPORTS)
    if not (have_db and have_exports):
        build = importlib.import_module("build")
        build.build_dw()

def _ensure_exports_present():
    _ensure_dw_built()
    for name in EXPECTED_EXPORTS:
        assert os.path.exists(os.path.join(EXPORTS_DIR, name)), f"Missing export: {name}"

def _ensure_plots_present():
    missing = [p for p in EXPECTED_PLOTS if not os.path.exists(os.path.join(PLOTS_DIR, p))]
    if not missing:
        return
    from scripts.visualization import generate_charts
    _ensure_exports_present()
    charts = {
        "rolling_call_volume.png": generate_charts.chart_rolling_call_volume(),
        "state_heatmap.png": generate_charts.chart_state_heatmap(),
        "customer_segments.png": generate_charts.chart_customer_segments(),
    }
    for fname, fig in charts.items():
        if fig is None:
            continue
        fig.savefig(os.path.join(PLOTS_DIR, fname), bbox_inches="tight")

def _ensure_alerts_logged():
    if not os.path.exists(ALERTS_LOG) or os.path.getsize(ALERTS_LOG) == 0:
        from scripts.automation.alert_drop_rate import run_alerts
        _ensure_exports_present()
        run_alerts()

# Cleaning modules & functions present
def test_cleaning_modules_and_functions_present():
    mod_cdr = importlib.import_module("scripts.cleaning.clean_cdr_calls")
    mod_cust = importlib.import_module("scripts.cleaning.clean_customers")
    mod_tow = importlib.import_module("scripts.cleaning.clean_towers")
    assert hasattr(mod_cdr, "clean_cdr_calls") and callable(mod_cdr.clean_cdr_calls)
    assert hasattr(mod_cust, "clean_customers") and callable(mod_cust.clean_customers)
    assert hasattr(mod_tow, "clean_towers") and callable(mod_tow.clean_towers)

# Processed data exists & is sane
def test_processed_data_exists_and_has_rows():
    _ensure_dirs()
    cust_path = os.path.join(PROCESSED_DIR, "customers_clean.csv")
    tow_path = os.path.join(PROCESSED_DIR, "towers_clean.csv")
    assert os.path.exists(cust_path), "customers_clean.csv missing"
    assert os.path.exists(tow_path), "towers_clean.csv missing"
    df_c = pd.read_csv(cust_path)
    df_t = pd.read_csv(tow_path)
    assert len(df_c) > 0, "customers_clean.csv is empty"
    assert len(df_t) > 0, "towers_clean.csv is empty"
    cdr_files = glob.glob(os.path.join(PROCESSED_CDR_DIR, "*.csv"))
    assert len(cdr_files) > 0, "No cleaned CDR split files found in processed/cdr_calls/"
    df_sample = pd.read_csv(cdr_files[0], nrows=5)
    assert len(df_sample.columns) >= 10, "CDR cleaned file has too few columns"


#  SQL execution (tables + views exist and have rows)
def test_sql_dw_tables_and_views_have_data():
    _ensure_dw_built()
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    for tbl in ["dim_customer", "dim_tower", "fact_calls"]:
        cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name=?", (tbl,))
        assert cur.fetchone(), f"Table missing: {tbl}"
        cur.execute(f"SELECT COUNT(*) FROM {tbl}")
        assert cur.fetchone()[0] > 0, f"Table {tbl} has no rows"
    for vw in ["view_drop_rate_by_state","view_operator_quality","view_peak_hours","view_tower_performance","view_heavy_users"]:
        cur.execute("SELECT name FROM sqlite_master WHERE type='view' AND name=?", (vw,))
        assert cur.fetchone(), f"View missing: {vw}"
    conn.close()

# Exports directory & files exist
def test_exports_dir_and_files_exist():
    _ensure_exports_present()
    for name in EXPECTED_EXPORTS:
        assert os.path.exists(os.path.join(EXPORTS_DIR, name)), f"Missing export: {name}"

# Exported CSVs have data
def test_exports_have_rows():
    _ensure_exports_present()
    for name in EXPECTED_EXPORTS:
        df = pd.read_csv(os.path.join(EXPORTS_DIR, name))
        assert len(df) > 0, f"Export {name} has no rows"

# Exports schema & sample checks (since dataset is static)
def test_exports_schema_and_sample_values():
    _ensure_exports_present()

    # drop_rate_by_state.csv
    dr = pd.read_csv(os.path.join(EXPORTS_DIR, "drop_rate_by_state.csv"))
    for col in ["state_name", "drop_rate_pct"]:
        assert col in dr.columns
    assert dr["drop_rate_pct"].between(0, 100).all()

    # operator_quality.csv
    oq = pd.read_csv(os.path.join(EXPORTS_DIR, "operator_quality.csv"))
    for col in ["operator_name", "avg_signal"]:
        assert col in oq.columns
    # realistic signal range
    assert oq["avg_signal"].between(-150, -50).all()

    # peak_hours.csv
    ph = pd.read_csv(os.path.join(EXPORTS_DIR, "peak_hours.csv"))
    for col in ["hour", "total_calls"]:
        assert col in ph.columns
    assert ph["hour"].between(0, 23).all()
    assert (ph["total_calls"] >= 0).all()

    # tower_performance.csv
    tp = pd.read_csv(os.path.join(EXPORTS_DIR, "tower_performance.csv"))
    assert "tower_id" in tp.columns and "total_calls" in tp.columns
    assert (tp["total_calls"] >= 0).all()

    # heavy_users.csv
    hu = pd.read_csv(os.path.join(EXPORTS_DIR, "heavy_users.csv"))
    for col in ["caller_number", "call_count", "total_duration"]:
        assert col in hu.columns
    assert (hu["call_count"] >= 0).all()
    assert (hu["total_duration"] >= 0).all()

# Main modules & functions present (top-level only)
def test_main_modules_and_functions_present():
    main_mod = importlib.import_module("main")
    viz_mod = importlib.import_module("scripts.visualization.generate_charts")
    assert hasattr(main_mod, "run_main") and callable(main_mod.run_main)
    for fn in ["chart_rolling_call_volume", "chart_state_heatmap", "chart_customer_segments"]:
        assert hasattr(viz_mod, fn) and callable(getattr(viz_mod, fn))

# Alerts log exists and has at least something
def test_alerts_log_written():
    _ensure_alerts_logged()
    assert os.path.exists(ALERTS_LOG), "alerts.log not found"
    assert os.path.getsize(ALERTS_LOG) > 0, "alerts.log is empty"

# alerts.log contains at least one state name
def test_alerts_log_contains_any_state_name():
    _ensure_alerts_logged()
    with open(ALERTS_LOG, "r") as f:
        content = f.read().lower()
    found_any = any(state.lower() in content for state in INDIAN_STATES)
    assert found_any, "alerts.log does not contain any expected state name"

# Plots exist in data/plots
def test_plots_exist_and_nonempty():
    _ensure_plots_present()
    for name in EXPECTED_PLOTS:
        path = os.path.join(PLOTS_DIR, name)
        assert os.path.exists(path), f"Missing plot: {name}"
        assert os.path.getsize(path) > 0, f"Plot is empty: {name}"
